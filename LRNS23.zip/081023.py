from PIL import Image  # Python Imaging Library
import numpy as np

#ZADANIE 1
obrazek = Image.open("inicjaly.bmp")
#obrazek.show()


#ZADANIE2
print("---------- informacje o obrazie")
print("tryb:", obrazek.mode)
print("format:", obrazek.format)
print("rozmiar:", obrazek.size)
#ZADANIE3
dane_obrazka = np.asarray(obrazek)
dane_obrazka1 = dane_obrazka * 1

t1_text = open('inicjaly.txt', 'w')
for rows in dane_obrazka1:
    for item in rows:
        t1_text.write(str(item) + ' ')
    t1_text.write('\n')

t1_text.close()
#ZADANIE4 (a
t1 = np.loadtxt("inicjaly.txt", dtype=np.bool_)
print("typ danych tablicy t1:", t1.dtype)
print("rozmiar tablicy t1 :", t1.shape)
print("wymiar tablicy t1 :", t1.ndim)
print("rozmiar wyrazu tablicy:",t1.itemsize)
print("liczba elementow:", t1.size)





